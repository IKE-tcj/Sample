﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class UserInput : MonoBehaviour
{
    public GameObject slotl;
    private Solitaire solitaire_Test;
    private float timer;
    private float doubleClickTimer = 0.3f;
    private int clickCount = 0;

    void Start()
    {
        solitaire_Test = FindObjectOfType<Solitaire>();
        slotl = this.gameObject;
    }

    void Update()
    {
        if (clickCount == 1)
        {
            timer += Time.deltaTime;
        }
        if (clickCount == 3)
        {
            timer = 0;
            clickCount = 1;
        }
        if (timer > doubleClickTimer)
        {
            timer = 0;
            clickCount = 0;
        }

        GetMouseClick();
    }

    void GetMouseClick()
    {
        if (Input.GetMouseButtonDown(0))
        {
            clickCount++;

            Vector3 mousePosition = Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y - 10));
            RaycastHit2D hit = Physics2D.Raycast(Camera.main.ScreenToWorldPoint(Input.mousePosition), Vector2.zero);
            if (hit)
            {
                //hitしたのは何か、、、
                if (hit.collider.CompareTag("Deck"))
                {
                    //clicked deck
                    Deck();
                }
                else if (hit.collider.CompareTag("Card"))
                {
                    //clicked card
                    Card(hit.collider.gameObject);
                }
                else if (hit.collider.CompareTag("Top"))
                {
                    //clicked top
                    Top(hit.collider.gameObject);
                }
                else if (hit.collider.CompareTag("Bottom"))
                {
                    //clicked bottom
                    Bottom(hit.collider.gameObject);
                }
            }
        }
    }

    void Deck()
    {
        //deck click actions
        Debug.Log("Deckを押したよ！");
        solitaire_Test.DealFromDeck();
        slotl = this.gameObject;
    }
    void Card(GameObject selected)
    {
        //card click actions
        Debug.Log("Cardを押したよ！");

        if (!selected.GetComponent<Selectable>().faceUp)//if the card clicked on is facedown
        {
            if (!Blocked(selected))//if the card clicked on is not blocked
            {
                //flikp it over
                selected.GetComponent<Selectable>().faceUp = true;
                slotl = this.gameObject;
            }
        }
        else if (selected.GetComponent<Selectable>().inDeckPile)
        {
            if (!Blocked(selected))
            {
                if (slotl == selected)
                {
                    if (DoubleClick())
                    {
                        AutoStack(selected);
                    }
                }
                else
                {
                    slotl = selected;
                }
            }
        }
        else
        {
            if (slotl == this.gameObject)
            {
                slotl = selected;
            }
            else if (slotl != selected)
            {
                if (Stackable(selected))
                {
                    Stack(selected);
                }
                else
                {
                    slotl = selected;
                }
            }
            else if (slotl == selected)
            {
                if (DoubleClick())
                {
                    AutoStack(selected);
                }
            }
        }
    }

    void Top(GameObject selected)
    {
        //top click actions
        Debug.Log("Topを押したよ！");

        if (slotl.CompareTag("Card"))
        {
            if (slotl.GetComponent<Selectable>().value == 1)
            {
                Stack(selected);
            }
        }

    }
    void Bottom(GameObject selected)
    {
        //bottom click actions
        Debug.Log("Bottomを押したよ！");

        if (slotl.CompareTag("Card"))
        {
            if (slotl.GetComponent<Selectable>().value == 13)
            {
                Stack(selected);
            }
        }

    }

    bool Stackable(GameObject selected)
    {
        Selectable s1 = slotl.GetComponent<Selectable>();
        Selectable s2 = selected.GetComponent<Selectable>();
        //compare them to see if they stack


        if (!s2.inDeckPile)
        {
            if (s2.top) //if in the top pile must stack suited Ace to King
            {
                if (s1.suit == s2.suit || (s1.value == 1 && s2.suit == null))
                {
                    if (s1.value == s2.value + 1)
                    {
                        return true;
                    }
                }
                else
                {
                    return false;
                }
            }
            else //if in the bottom pile must stack alternate colours King to Ace
            {
                if (s1.value == s2.value - 1)
                {
                    bool card1Red = true;
                    bool card2Red = true;

                    if (s1.suit == "C" || s1.suit == "S")
                    {
                        card1Red = false;
                    }

                    if (s2.suit == "C" || s2.suit == "S")
                    {
                        card2Red = false;
                    }

                    if (card1Red == card2Red)
                    {
                        Debug.Log("Not stackble");
                        return false;
                    }
                    else
                    {
                        Debug.Log("stackable");
                        return true;
                    }

                }

            }
        }
        return false;
    }

    void Stack(GameObject selected)
    {
        Selectable s1 = slotl.GetComponent<Selectable>();
        Selectable s2 = selected.GetComponent<Selectable>();
        float yOffset = 0.3f;

        if (s2.top || (!s2.top && s1.value == 13))
        {
            yOffset = 0;
        }

        slotl.transform.position = new Vector3(selected.transform.position.x, selected.transform.position.y - yOffset, selected.transform.position.z - 0.01f);
        slotl.transform.parent = selected.transform;//this makes the children move with the parents

        if (s1.inDeckPile)
        {
            solitaire_Test.tripsOnDisplay.Remove(slotl.name);
        }
        else if (s1.top && s2.top && s1.value == 1)
        {
            solitaire_Test.topPos[s1.row].GetComponent<Selectable>().value = 0;
            solitaire_Test.topPos[s1.row].GetComponent<Selectable>().suit = null;
        }
        else if (s1.top)
        {
            solitaire_Test.topPos[s1.row].GetComponent<Selectable>().value = s1.value - 1;
        }
        else
        {
            solitaire_Test.bottoms[s1.row].Remove(slotl.name);
        }
        s1.inDeckPile = false;
        s1.row = s2.row;

        if (s2.top)
        {
            solitaire_Test.topPos[s1.row].GetComponent<Selectable>().value = s1.value;
            solitaire_Test.topPos[s1.row].GetComponent<Selectable>().suit = s1.suit;
            s1.top = true;
        }
        else
        {
            s1.top = false;
        }
        slotl = this.gameObject;

    }

    bool Blocked(GameObject selected)
    {
        Selectable s2 = selected.GetComponent<Selectable>();
        if (s2.inDeckPile == true)
        {
            if (s2.name == solitaire_Test.tripsOnDisplay.Last())
            {
                return false;

            }
            else
            {
                Debug.Log(s2.name + " is blocked by " + solitaire_Test.tripsOnDisplay.Last());
                return true;
            }
        }
        else
        {
            if (s2.name == solitaire_Test.bottoms[s2.row].Last())
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }

    bool DoubleClick()
    {
        if (timer < doubleClickTimer && clickCount == 2)
        {
            Debug.Log("Double Click");
            return true;
        }
        else
        {
            return false;
        }
    }

    void AutoStack(GameObject selected)
    {
        for (int i = 0; i < solitaire_Test.topPos.Length; i++)
        {
            Selectable stack = solitaire_Test.topPos[i].GetComponent<Selectable>();
            if (selected.GetComponent<Selectable>().value == 1)
            {
                if (solitaire_Test.topPos[i].GetComponent<Selectable>().value == 0)
                {
                    slotl = selected;
                    Stack(stack.gameObject);
                    break;
                }
            }
            else
            {
                if ((solitaire_Test.topPos[i].GetComponent<Selectable>().suit == slotl.GetComponent<Selectable>().suit) && (solitaire_Test.topPos[i].GetComponent<Selectable>().value == slotl.GetComponent<Selectable>().value - 1))
                {
                    if (HasNoChildren(slotl))
                    {
                        slotl = selected;
                        string lastCardname = stack.suit + stack.value.ToString();
                        if (stack.value == 1)
                        {
                            lastCardname = stack.suit + "A";
                        }
                        if (stack.value == 11)
                        {
                            lastCardname = stack.suit + "J";
                        }
                        if (stack.value == 12)
                        {
                            lastCardname = stack.suit + "Q";
                        }
                        if (stack.value == 13)
                        {
                            lastCardname = stack.suit + "K";
                        }
                        GameObject lastCard = GameObject.Find(lastCardname);
                        Stack(lastCard);
                        break;
                    }
                }
            }
        }
    }

    bool HasNoChildren(GameObject card)
    {
        int i = 0;
        foreach(Transform child in card.transform)
        {
            i++;
        }
        if(i == 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

}
