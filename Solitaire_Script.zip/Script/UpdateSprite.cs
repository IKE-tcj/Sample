﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UpdateSprite : MonoBehaviour
{
    public Sprite cardFace;//表
    public Sprite cardBack;//裏

    private SpriteRenderer spriteRenderer;
    private Selectable selectable_Test;
    private Solitaire solitaire_Test;
    private UserInput userInput_Test;

    void Start()
    {
        List<string> deck = Solitaire.GenerateDeck();
        solitaire_Test = FindObjectOfType<Solitaire>();
        userInput_Test = FindObjectOfType<UserInput>();

        int i = 0;
        foreach(string card in deck)
        {
            if(this.name == card)
            {
                cardFace = solitaire_Test.cardFaces[i];
                break;
            }
            i++;
        }
        spriteRenderer = GetComponent<SpriteRenderer>();
        selectable_Test = GetComponent<Selectable>();
    }

    void Update()
    {
        if(selectable_Test.faceUp == true)
        {
            spriteRenderer.sprite = cardFace;
        }
        else
        {
            spriteRenderer.sprite = cardBack;
        }

        if (userInput_Test.slotl)
        {
            if(name == userInput_Test.slotl.name)
            {
                spriteRenderer.color = Color.yellow;
            }
            else
            {
                spriteRenderer.color = Color.white;
            }
        }
    }
}
